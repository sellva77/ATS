import { useEffect, useState } from "react";
import { toast } from "../components/common/Toast";
import { listUsers, inviteUser, updateUserTeam, deleteUser } from "../api/user";
import { useAuth } from "../context/AuthContext";
import { listTeams, type Team } from "../api/team";
import { type User } from "../types";
import { PageHeader } from "../components/layout/PageHeader";
import { Modal } from "../components/common/Modal";

export function UsersPage() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);

  // Invite Form
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [selectedTeamId, setSelectedTeamId] = useState("");
  const [isInviting, setIsInviting] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [usersData, teamsData] = await Promise.all([
        listUsers(),
        listTeams(),
      ]);
      // Only show team managers
      setUsers(usersData.filter((u: any) => u.role?.name === "TEAM_MANAGER"));
      setTeams(teamsData);
    } catch (error: any) {
      toast.error(error.message || "Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    try {
      setIsInviting(true);
      const newUser = await inviteUser(
        email.trim(),
        "TEAM_MANAGER",
        name.trim() || undefined,
        undefined,
        selectedTeamId || undefined
      );
      setUsers([newUser as any, ...users]);
      setEmail("");
      setName("");
      setPhone("");
      setIsModalOpen(false);
      toast.success("Team Manager invited successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to invite manager");
    } finally {
      setIsInviting(false);
    }
  };

  const handleTeamChange = async (userId: string, newTeamId: string) => {
    try {
      await updateUserTeam(userId, newTeamId || null);
      setUsers(users.map(u => u.id === userId ? { ...u, teamId: newTeamId || null } : u));
      toast.success("Team updated");
    } catch (error: any) {
      toast.error(error.message || "Failed to update team");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to remove this manager?")) return;

    try {
      await deleteUser(id);
      setUsers(users.filter((u) => u.id !== id));
      toast.success("Manager removed");
    } catch (error: any) {
      toast.error(error.message || "Failed to remove manager");
    }
  };

  return (
    <>
      <PageHeader
        icon="🧑‍💼"
        title="Team Managers"
        description="Create and manage team managers who handle candidate pipelines."
      />
      <div className="page-body">
      <div style={{ marginBottom: "2rem", display: "flex", justifyContent: "flex-end" }}>
        <button className="search-btn" onClick={() => setIsModalOpen(true)}>
          Invite Manager
        </button>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Invite New Team Manager">
        <form onSubmit={handleInvite} className="search-form">
          <div className="search-controls" style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <input
              type="text"
              className="search-textarea"
              placeholder="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isInviting}
              style={{ width: "100%", minHeight: "44px", height: "44px", padding: "0 16px" }}
              autoFocus
            />
            <input
              type="email"
              className="search-textarea"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isInviting}
              required
              style={{ width: "100%", minHeight: "44px", height: "44px", padding: "0 16px" }}
            />
            <input
              type="tel"
              className="search-textarea"
              placeholder="Phone (optional)"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              disabled={isInviting}
              style={{ width: "100%", minHeight: "44px", height: "44px", padding: "0 16px" }}
            />

            <select className="search-textarea" style={{ width: "100%", minHeight: "44px", height: "44px", padding: "0 16px" }} value={selectedTeamId} onChange={(e) => setSelectedTeamId(e.target.value)} disabled={isInviting}>
              <option value="">No Team</option>
              {teams.map(team => (
                <option key={team.id} value={team.id}>{team.name}</option>
              ))}
            </select>
            
            <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px", marginTop: "8px" }}>
              <button 
                type="button" 
                className="search-btn" 
                style={{ background: "var(--bg-secondary)", color: "var(--text-primary)" }}
                onClick={() => setIsModalOpen(false)}
                disabled={isInviting}
              >
                Cancel
              </button>
              <button type="submit" className="search-btn" disabled={isInviting || !email.trim()}>
                {isInviting ? (
                  <>
                    <span className="spinner-inline" />
                    Inviting...
                  </>
                ) : (
                  "Invite Manager"
                )}
              </button>
            </div>
          </div>
        </form>
      </Modal>

      <div>
        {loading ? (
          <div className="status-indicator processing">Loading...</div>
        ) : users.length === 0 ? (
          <div className="empty-state">
            <span className="empty-state-icon">🧑‍💼</span>
            <h3>No team managers found</h3>
            <p>Invite your first team manager above to get started.</p>
          </div>
        ) : (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Team</th>
                  <th>Joined</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="font-medium text-heading">{u.name || "N/A"}</td>
                    <td>{u.email}</td>
                    <td>{(u as any).phone || "-"}</td>
                    <td>
                      <select 
                        className="search-textarea"
                        style={{ padding: "4px 8px", minHeight: "32px" }}
                        value={u.teamId || ""}
                        onChange={(e) => handleTeamChange(u.id, e.target.value)}
                      >
                        <option value="">No Team</option>
                        {teams.map(team => (
                          <option key={team.id} value={team.id}>{team.name}</option>
                        ))}
                      </select>
                    </td>
                    <td className="text-muted text-sm">
                      {new Date((u as any).createdAt).toLocaleDateString()}
                    </td>
                    <td>
                      <button 
                        className="delete-btn"
                        title="Remove manager"
                        onClick={() => handleDelete(u.id)}
                      >
                        🗑
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
    </>
  );
}
